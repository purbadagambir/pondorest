<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PointLogs extends Model
{
    protected $table ="point_Logs";
}
