<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sales extends Model
{
    protected $table="selling_info";
    protected $primaryKey ='invoice_id';
}
